MARSWALK 2.0 / PROJECT ATLAS — MISSION EVIDENCE DOSSIER
=========================================================
Experiment ID: mexp_20261104_201639_bf983e65
Campaign ID:   cmp_13a_val_test
Date:          2026-11-04T20:16:39.424723+00:00

ARCHIVE CONTENTS:
- manifest.json:               Cryptographic integrity manifest with per-file SHA-256 hashes
- experiment_dossier.json:     Complete orchestration study record (Draft 2020-12)
- cross_scenario_matrix.csv:   RFC 4180 cross-scenario comparative matrix
- executive_briefing.md:       Flight director briefing and bottleneck analysis
- provenance.json:             USGS Jezero 20m DTM provenance, CRS ESRI:103885, SI units
- README.txt:                  Operational caveats and instructions

INTEGRITY VERIFICATION:
Inspect manifest.json to verify SHA-256 checksums for each file.

DISCLOSURES:
- Modeled routes are planning heuristics and NOT safe for astronauts.
- Non-probabilistic stress suite evaluations.
